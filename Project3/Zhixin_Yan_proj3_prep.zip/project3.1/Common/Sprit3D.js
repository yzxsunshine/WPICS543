function Sprit3D() {
	this.position = vec3(0, 0, 0);
	this.rotation = vec4(0, 0, 0);
}